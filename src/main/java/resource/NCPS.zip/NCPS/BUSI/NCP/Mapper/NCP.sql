
/*==============================================================*/
/* Table:T_SMS_INFO	*/
/*==============================================================*/
CREATE TABLE T_SMS_INFO(
			SMS_SEQ		int (10)  		 NOT NULL,
			CHNL_NO		varchar (3)  		 NOT NULL,
			ACCT_NO		varchar (40)  		 NULL,
			BRCH_NO		varchar (12)  		 NULL,
			PHN		varchar (18)  		 NULL,
			SMS_MSG		varchar (255)  		 NULL,
			SND_STAT		varchar (1)  		 NULL,
			CRT_DATE		varchar (19)  		 NULL,
			SND_DATE		varchar (19)  		 NULL,
			SND_TIMES		int (10)  		 NULL,
			RMRK		varchar (60)  		 NULL,
			RMRK1		varchar (100)  		 NULL
);

CREATE UNIQUE INDEX ui_t_sms_info ON T_SMS_INFO
(
SMS_SEQ,
CHNL_NO
);

/*==============================================================*/
/* Table:T_PUB_PARA	*/
/*==============================================================*/
CREATE TABLE T_PUB_PARA(
			PARA_TYPE		varchar (6)  		 NOT NULL,
			PARA_NO		varchar (100)  		 NOT NULL,
			STAT1		varchar (40)  		 NULL,
			STAT2		varchar (40)  		 NULL,
			VAL1		varchar (100)  		 NULL,
			VAL2		varchar (100)  		 NULL,
			MSG1		varchar (255)  		 NULL,
			MSG2		varchar (255)  		 NULL,
			INT_VAL1		int (10)  		 NOT NULL,
			INT_VAL2		int (10)  		 NOT NULL,
			STAT		varchar (1)  		 NOT NULL,
			DAC		varchar (16)  		 NULL
);

CREATE UNIQUE INDEX ui_t_pub_para ON T_PUB_PARA
(
PARA_TYPE,
PARA_NO
);

/*==============================================================*/
/* Table:T_PLAT_PARA	*/
/*==============================================================*/
CREATE TABLE T_PLAT_PARA(
			PLAT_NO		varchar (20)  		 NOT NULL,
			PLAT_NAME		varchar (60)  		 NULL,
			PLAT_STAT		varchar (1)  		 NULL,
			PLAT_DATE		varchar (8)  		 NULL,
			CLEAR_DATE		varchar (8)  		 NULL,
			ACT_DATE		varchar (8)  		 NULL,
			BRCH_NO		varchar (9)  		 NULL,
			DAYEND_FLAG		int (10)  		 NOT NULL,
			DAYEND_DATE		varchar (8)  		 NULL,
			DAYEND_TIME		varchar (6)  		 NULL,
			DAYEND_SEC		int (10)  		 NOT NULL,
			PASS_DAY		int (10)  		 NOT NULL,
			HIST_DAY		int (10)  		 NOT NULL,
			FILE_LEN		int (10)  		 NOT NULL,
			CHK_KEEP		int (10)  		 NOT NULL,
			PLAT_SEQ		int (10)  		 NULL,
			BAT_SEQ		int (10)  		 NULL,
			VERSION		varchar (9)  		 NULL,
			DAC		varchar (16)  		 NULL
);

CREATE UNIQUE INDEX ui_t_plat_para ON T_PLAT_PARA
(
PLAT_NO
);

/*==============================================================*/
/* Table:T_TX	*/
/*==============================================================*/
CREATE TABLE T_TX(
			TX_CODE		varchar (40)  		 NOT NULL,
			TX_TYPE		varchar (1)  		 NULL,
			TX_STAT		varchar (1)  		 NOT NULL,
			TX_NAME		varchar (60)  		 NULL,
			TX_INST_NUM		int (10)  		 NULL,
			INS_JRNL		varchar (1)  		 NULL,
			FLAG1		varchar (1)  		 NULL,
			FLAG2		varchar (1)  		 NULL,
			DAC		varchar (16)  		 NULL
);

CREATE UNIQUE INDEX ui_t_tx ON T_TX
(
TX_CODE
);

/*==============================================================*/
/* Table:T_ENTR	*/
/*==============================================================*/
CREATE TABLE T_ENTR(
			ENTR_NO		varchar (10)  		 NOT NULL,
			ENTR_NAME		varchar (60)  		 NULL,
			PRT_NAME		varchar (10)  		 NULL,
			BRCH_NO		varchar (9)  		 NULL,
			ENTR_STAT		varchar (1)  		 NULL,
			LOGIN_STAT		varchar (1)  		 NULL,
			LOGIN_FLAG		varchar (1)  		 NULL,
			AREA_NO		varchar (9)  		 NULL,
			OTH_CUST_NO		varchar (20)  		 NULL,
			ENTR_DATE		varchar (8)  		 NULL,
			DSCRP_CODE		varchar (4)  		 NULL,
			TRAN_MODE		varchar (1)  		 NULL,
			ACCT_TYPE0		varchar (1)  		 NULL,
			ACCT_TYPE1		varchar (1)  		 NULL,
			ACCT_TYPE2		varchar (1)  		 NULL,
			ACCT_TYPE3		varchar (1)  		 NULL,
			ACCT_TYPE4		varchar (1)  		 NULL,
			ACCT_TYPE5		varchar (1)  		 NULL,
			INPUT_TIME		varchar (6)  		 NULL,
			CHK_MAX		int (10)  		 NULL,
			CHK_SEQ		varchar (1)  		 NULL,
			CHK_OK		varchar (1)  		 NULL,
			CHK_STAT		varchar (1)  		 NULL,
			SPLIT_TOT		int (10)  		 NULL,
			BAT_NUM		int (10)  		 NULL,
			LOGIN_DATE		varchar (8)  		 NULL,
			LOGIN_TIME		varchar (6)  		 NULL,
			LOGOUT_DATE		varchar (8)  		 NULL,
			LOGOUT_TIME		varchar (6)  		 NULL,
			ADDR		varchar (80)  		 NULL,
			POST		varchar (6)  		 NULL,
			MNG_NAME		varchar (60)  		 NULL,
			TELE_NO		varchar (20)  		 NULL,
			RMRK		varchar (60)  		 NULL,
			RMRK1		varchar (100)  		 NULL,
			DAC		varchar (16)  		 NULL
);

CREATE UNIQUE INDEX ui_t_entr ON T_ENTR
(
ENTR_NO
);

/*==============================================================*/
/* Table:T_BUSI	*/
/*==============================================================*/
CREATE TABLE T_BUSI(
			ENTR_NO		varchar (10)  		 NOT NULL,
			BUSI_NO		varchar (4)  		 NOT NULL,
			BUSI_NAME		varchar (60)  		 NULL,
			PRT_NAME		varchar (10)  		 NULL,
			BUSI_DESC		varchar (255)  		 NULL,
			BUSI_STAT		varchar (1)  		 NULL,
			CURR_NO		varchar (3)  		 NULL,
			CURR_IDEN		varchar (1)  		 NULL,
			FEE_CODE		varchar (13)  		 NULL,
			AMT_LIMIT		decimal (16,2)  		 NULL,
			PAY_LIMIT		decimal (16,2)  		 NULL,
			CREDIT_FLAG		varchar (1)  		 NULL,
			SIGN_FLAG		varchar (1)  		 NULL,
			SIGN_CONDITION		varchar (2)  		 NULL,
			RMRK		varchar (60)  		 NULL,
			RMRK1		varchar (100)  		 NULL,
			DAC		varchar (16)  		 NULL
);

CREATE UNIQUE INDEX ui_t_busi ON T_BUSI
(
ENTR_NO,
BUSI_NO
);

/*==============================================================*/
/* Table:T_BUSI_OPEN	*/
/*==============================================================*/
CREATE TABLE T_BUSI_OPEN(
			BRCH_NO		varchar (9)  		 NOT NULL,
			ENTR_NO		varchar (10)  		 NOT NULL,
			BUSI_NO		varchar (4)  		 NOT NULL,
			BUSI_BANK1		varchar (12)  		 NULL,
			BUSI_BANK2		varchar (12)  		 NULL,
			IN_ACCT_NO		varchar (32)  		 NULL,
			OUT_ACCT_NO		varchar (32)  		 NULL,
			PAY_ACCT_NO		varchar (32)  		 NULL,
			FEE_ACCT_NO		varchar (32)  		 NULL,
			OPEN_FLAG		varchar (1)  		 NULL,
			DAC		varchar (16)  		 NULL
);

CREATE UNIQUE INDEX ui_t_busi_open ON T_BUSI_OPEN
(
BRCH_NO,
ENTR_NO,
BUSI_NO
);

/*==============================================================*/
/* Table:T_CHANNEL	*/
/*==============================================================*/
CREATE TABLE T_CHANNEL(
			CHN_NO		varchar (6)  		 NOT NULL,
			CHN_NAME		varchar (40)  		 NULL,
			CHN_STAT		varchar (1)  		 NULL,
			MNG_BRCH		varchar (9)  		 NULL,
			VTELLER		varchar (12)  		 NULL,
			VTERM		varchar (3)  		 NULL,
			RATE_CODE		varchar (13)  		 NULL,
			BEG_TIME		varchar (6)  		 NULL,
			END_TIME		varchar (6)  		 NULL,
			DAC		varchar (16)  		 NULL
);

CREATE UNIQUE INDEX ui_t_channel ON T_CHANNEL
(
CHN_NO
);

/*==============================================================*/
/* Table:T_CHANNEL_OPEN	*/
/*==============================================================*/
CREATE TABLE T_CHANNEL_OPEN(
			CHN_NO		varchar (6)  		 NOT NULL,
			ENTR_NO		varchar (10)  		 NOT NULL,
			BUSI_NO		varchar (4)  		 NOT NULL,
			OPEN_FLAG		varchar (1)  		 NULL,
			DAC		varchar (16)  		 NULL
);

CREATE UNIQUE INDEX ui_t_channel_open ON T_CHANNEL_OPEN
(
CHN_NO,
ENTR_NO,
BUSI_NO
);

/*==============================================================*/
/* Table:T_ENTR_BUSI	*/
/*==============================================================*/
CREATE TABLE T_ENTR_BUSI(
			ENTR_NO		varchar (10)  		 NOT NULL,
			ENTR_BRCH_NO		varchar (40)  		 NOT NULL,
			ENTR_BRCH_NAME		varchar (60)  		 NOT NULL,
			BUSI_NO		varchar (6)  		 NOT NULL,
			BUSI_NAME		varchar (60)  		 NOT NULL,
			PRT_NAME		varchar (20)  		 NULL,
			BUSI_BRCH_NO		varchar (6)  		 NOT NULL,
			ADM_BRCH_NO		varchar (6)  		 NULL,
			CHK_ACCT_SEQ		varchar (2)  		 NOT NULL,
			INV_VOUTYPE		varchar (4)  		 NULL,
			BUSI_STAT		varchar (1)  		 NOT NULL,
			LOGIN_STAT		varchar (1)  		 NOT NULL,
			LOGIN_PLAT_DATE		varchar (8)  		 NOT NULL,
			AUTO_LOGIN		varchar (1)  		 NOT NULL,
			LOGIN_TYPE		varchar (1)  		 NOT NULL,
			LOGIN_DTA		varchar (80)  		 NULL,
			LOGIN_SVC		varchar (80)  		 NULL,
			ENTR_DATE		varchar (8)  		 NOT NULL,
			ENTR_CHK_PARA1		varchar (80)  		 NULL,
			ENTR_CHK_PARA2		varchar (80)  		 NULL,
			ACCT_FLAG		varchar (1)  		 NOT NULL,
			CURR_NO		varchar (2)  		 NOT NULL,
			CURR_IDEN		varchar (1)  		 NOT NULL,
			START_TIME		varchar (6)  		 NOT NULL,
			END_TIME		varchar (6)  		 NOT NULL,
			MIN_AMT		decimal (16,2)  		 NULL,
			MAX_AMT		decimal (16,2)  		 NULL,
			PAY_ACCT_NO		varchar (32)  		 NULL,
			PAY_INTR_ACCT_NO		varchar (32)  		 NULL,
			PAYEE_ACCT_NO		varchar (32)  		 NULL,
			PAYEE_INTR_ACCT_NO		varchar (32)  		 NULL,
			INTR_FLAG		varchar (1)  		 NOT NULL,
			AUTO_ACCT_FLAG		varchar (1)  		 NOT NULL,
			AUTO_ACCT_STAT		varchar (1)  		 NOT NULL,
			AUTO_ACCT_DATE		varchar (8)  		 NOT NULL,
			CHK_SEQ		varchar (1)  		 NOT NULL,
			CHK_STAT		varchar (1)  		 NULL,
			CRT_PSN		varchar (20)  		 NULL,
			CRT_TIME		varchar (14)  		 NULL,
			MOD_PSN		varchar (20)  		 NULL,
			MOD_TIME		varchar (14)  		 NULL,
			BUSI_RMRK1		varchar (40)  		 NULL,
			BUSI_RMRK2		varchar (40)  		 NULL,
			AMT_RMRK1		decimal (16,2)  		 NULL,
			AMT_RMRK2		decimal (16,2)  		 NULL,
			AMT_RMRK3		decimal (16,5)  		 NULL,
			AMT_RMRK4		decimal (16,5)  		 NULL,
			NUM_RMRK1		int (10)  		 NULL,
			NUM_RMRK2		int (10)  		 NULL,
			DAC		varchar (16)  		 NULL
);

CREATE UNIQUE INDEX ui_t_entr_busi ON T_ENTR_BUSI
(
ENTR_NO,
ENTR_BRCH_NO,
ENTR_BRCH_NAME,
BUSI_NO
);

/*==============================================================*/
/* Table:T_NCP_BOOK	*/
/*==============================================================*/
CREATE TABLE T_NCP_BOOK(
			PLAT_DATE		varchar (8)  		 NULL,
			SEQ_NO		int (10)  		 NULL,
			TX_CODE		varchar (40)  		 NULL,
			TX_NAME		varchar (60)  		 NULL,
			TX_DATE		varchar (19)  		 NULL,
			TX_SEQ		varchar (16)  		 NULL,
			PAY_ACCT_NO		varchar (34)  		 NULL,
			PAY_ACCT_NAME		varchar (60)  		 NULL,
			PAY_BRCH		varchar (12)  		 NULL,
			PAY_ACCT_TYPE		varchar (2)  		 NULL,
			PAY_CERT_TYPE		varchar (2)  		 NULL,
			PAY_CERT_NO		varchar (20)  		 NULL,
			PAYEE_ACCT_NO		varchar (34)  		 NULL,
			PAYEE_ACCT_NAME		varchar (60)  		 NULL,
			PAY_PHN		varchar (18)  		 NULL,
			PAYEE_BRCH		varchar (12)  		 NULL,
			PAYEE_ACCT_TYPE		varchar (2)  		 NULL,
			PAYEE_CERT_TYPE		varchar (2)  		 NULL,
			PAYEE_CERT_NO		varchar (20)  		 NULL,
			PAYEE_AREA		varchar (4)  		 NULL,
			TX_TYPE		varchar (2)  		 NULL,
			ENTR_NO		varchar (10)  		 NULL,
			CHNL_NO		varchar (6)  		 NULL,
			SND_TIME		varchar (19)  		 NULL,
			SND_BRCH		varchar (12)  		 NULL,
			SND_BRCH_NO		varchar (12)  		 NULL,
			SND_ACCT_BRCH		varchar (12)  		 NULL,
			BRCH_NO		varchar (12)  		 NULL,
			BUSI_TYPE		varchar (10)  		 NULL,
			TELLER_NO		varchar (10)  		 NULL,
			CHK_ACT_NO		varchar (30)  		 NULL,
			OTH_DATE		varchar (19)  		 NULL,
			OTH_SEQ		varchar (16)  		 NULL,
			TX_AMT		decimal (16,2)  		 NULL,
			ACCT_INPUT		varchar (6)  		 NULL,
			TERM_TYPE		varchar (2)  		 NULL,
			TERM_NO		varchar (8)  		 NULL,
			RP_FLAG		varchar (2)  		 NULL,
			CLEAR_DATE		varchar (10)  		 NULL,
			SIGN_NO		varchar (55)  		 NULL,
			PRODUCT_TYPE		varchar (8)  		 NULL,
			ORDER_NO		varchar (40)  		 NULL,
			ORI_OTH_SEQ		varchar (16)  		 NULL,
			ORI_TX_AMT		decimal (16,2)  		 NULL,
			ORI_ORDER_NO		varchar (40)  		 NULL,
			ORI_TX_DATE		varchar (19)  		 NULL,
			ACCT_LVL		varchar (2)  		 NULL,
			CHK_STAT		varchar (2)  		 NULL,
			STAT		varchar (2)  		 NULL,
			RET_CODE		varchar (10)  		 NULL,
			RET_MSG		varchar (128)  		 NULL,
			HOST_MSG		varchar (128)  		 NULL,
			RET_TIME		varchar (19)  		 NULL,
			TIME_SEC		int (10)  		 NULL,
			OPEN_BRCH		varchar (12)  		 NULL,
			HOST_DATE		varchar (19)  		 NULL,
			HOST_SEQ		varchar (20)  		 NULL,
			REFUND_AMT		double (16,2)  		 NULL,
			CHK_FLAG		varchar (20)  		 NULL,
			CHK_MSG		varchar (60)  		 NULL,
			AMT1		double (16,2)  		 NULL,
			AMT2		double (16,2)  		 NULL,
			RMRK		varchar (60)  		 NULL,
			RMRK1		varchar (100)  		 NULL,
			RMRK2		varchar (200)  		 NULL,
			MRCHNT_NO		varchar (15)  		 NULL,
			MRCHNT_NAME		char (80)  		 NULL,
			ORDER_DESC		char (128)  		 NULL
);


/*==============================================================*/
/* Table:T_NCP_BOOK_EXT	*/
/*==============================================================*/
CREATE TABLE T_NCP_BOOK_EXT(
			PLAT_DATE		varchar (8)  		 NULL,
			SEQ_NO		int (10)  		 NULL,
			TX_CODE		varchar (40)  		 NULL,
			MRCHNT_NO		varchar (15)  		 NULL,
			MRCHNT_TYPE		varchar (4)  		 NULL,
			MRCHNT_NAME		varchar (80)  		 NULL,
			SUBMRCHNT_NO		varchar (15)  		 NULL,
			SUBMRCHNT_TYPE		varchar (4)  		 NULL,
			SUBMRCHNT_NAME		varchar (80)  		 NULL,
			INST_BRCH		varchar (11)  		 NULL,
			INST_ACCT_NO		varchar (34)  		 NULL,
			INST_ACCT_NAME		varchar (120)  		 NULL,
			DEV_DES		varchar (400)  		 NULL,
			DEV_LANG		varchar (3)  		 NULL,
			IP		varchar (64)  		 NULL,
			MAC		varchar (64)  		 NULL,
			DEV_NO		varchar (129)  		 NULL,
			GPS		varchar (32)  		 NULL,
			SIM_NO		varchar (32)  		 NULL,
			SIM_NUM		int (10)  		 NULL,
			USER_ID		varchar (100)  		 NULL,
			RISK		varchar (8)  		 NULL,
			REASON		varchar (200)  		 NULL,
			REG_DATE		varchar (14)  		 NULL,
			EMAIL		varchar (128)  		 NULL,
			PRO_CODE		varchar (4)  		 NULL,
			CITY_CODE		varchar (4)  		 NULL,
			GOOD_TYPE		varchar (10)  		 NULL,
			CHNL_BRCH		varchar (100)  		 NULL,
			ENTR_ACCT_NAME		varchar (240)  		 NULL,
			RGST_NO		varchar (20)  		 NULL,
			SND_ACCT_NO		varchar (34)  		 NULL,
			PAY_ACCT_INFO		varchar (64)  		 NULL,
			PRODUCT_DESC		varchar (240)  		 NULL,
			ORDER_DESC		varchar (128)  		 NULL,
			AMT1		double (16,2)  		 NULL,
			AMT2		double (16,2)  		 NULL,
			RMRK		varchar (60)  		 NULL,
			RMRK1		varchar (100)  		 NULL,
			RMRK2		varchar (200)  		 NULL
);

CREATE UNIQUE INDEX ui_t_ncp_book_ext ON T_NCP_BOOK_EXT
(
PLAT_DATE,
SEQ_NO
);

/*==============================================================*/
/* Table:T_NCP_WAIT_SND	*/
/*==============================================================*/
CREATE TABLE T_NCP_WAIT_SND(
			PLAT_DATE		varchar (8)  		 NOT NULL,
			SEQ_NO		int (10)  		 NOT NULL,
			DTA_NAME		varchar (50)  		 NULL,
			SVC_NAME		varchar (50)  		 NULL,
			TX_TYPE		varchar (10)  		 NULL,
			STAT		varchar (2)  		 NOT NULL,
			DATA		varchar (2048)  		 NOT NULL,
			SND_DATE		varchar (19)  		 NOT NULL,
			SND_TIMES		int (10)  		 NOT NULL,
			RET_CODE		varchar (20)  		 NULL,
			RET_MSG		varchar (120)  		 NULL,
			REASON		varchar (40)  		 NULL,
			RMRK		varchar (60)  		 NULL,
			RMRK1		varchar (100)  		 NULL,
			RMRK2		varchar (200)  		 NULL
);

CREATE UNIQUE INDEX uidx_t_ncp_wait_snd ON T_NCP_WAIT_SND
(
PLAT_DATE,
SEQ_NO
);
CREATE INDEX i_t_ncp_wait_snd1 ON T_NCP_WAIT_SND
(
STAT,
SND_DATE,
SND_TIMES
);

/*==============================================================*/
/* Table:T_NCP_BOOK_HIST	*/
/*==============================================================*/
CREATE TABLE T_NCP_BOOK_HIST(
			PLAT_DATE		varchar (8)  		 NULL,
			SEQ_NO		int (10)  		 NULL,
			TX_CODE		varchar (40)  		 NULL,
			TX_NAME		varchar (60)  		 NULL,
			TX_DATE		varchar (19)  		 NULL,
			TX_SEQ		varchar (16)  		 NULL,
			PAY_ACCT_NO		varchar (34)  		 NULL,
			PAY_ACCT_NAME		varchar (60)  		 NULL,
			PAY_BRCH		varchar (12)  		 NULL,
			PAY_ACCT_TYPE		varchar (2)  		 NULL,
			PAY_CERT_TYPE		varchar (2)  		 NULL,
			PAY_CERT_NO		varchar (20)  		 NULL,
			PAYEE_ACCT_NO		varchar (34)  		 NULL,
			PAYEE_ACCT_NAME		varchar (60)  		 NULL,
			PAY_PHN		varchar (18)  		 NULL,
			PAYEE_BRCH		varchar (12)  		 NULL,
			PAYEE_ACCT_TYPE		varchar (2)  		 NULL,
			PAYEE_CERT_TYPE		varchar (2)  		 NULL,
			PAYEE_CERT_NO		varchar (20)  		 NULL,
			PAYEE_AREA		varchar (4)  		 NULL,
			TX_TYPE		varchar (2)  		 NULL,
			ENTR_NO		varchar (10)  		 NULL,
			CHNL_NO		varchar (6)  		 NULL,
			SND_TIME		varchar (19)  		 NULL,
			SND_BRCH		varchar (12)  		 NULL,
			SND_BRCH_NO		varchar (12)  		 NULL,
			SND_ACCT_BRCH		varchar (12)  		 NULL,
			BRCH_NO		varchar (12)  		 NULL,
			BUSI_TYPE		varchar (10)  		 NULL,
			TELLER_NO		varchar (10)  		 NULL,
			CHK_ACT_NO		varchar (30)  		 NULL,
			OTH_DATE		varchar (19)  		 NULL,
			OTH_SEQ		varchar (16)  		 NULL,
			TX_AMT		decimal (16,2)  		 NULL,
			ACCT_INPUT		varchar (6)  		 NULL,
			TERM_TYPE		varchar (2)  		 NULL,
			TERM_NO		varchar (8)  		 NULL,
			RP_FLAG		varchar (2)  		 NULL,
			CLEAR_DATE		varchar (10)  		 NULL,
			SIGN_NO		varchar (55)  		 NULL,
			PRODUCT_TYPE		varchar (8)  		 NULL,
			ORDER_NO		varchar (40)  		 NULL,
			ORI_OTH_SEQ		varchar (16)  		 NULL,
			ORI_TX_AMT		decimal (16,2)  		 NULL,
			ORI_ORDER_NO		varchar (40)  		 NULL,
			ORI_TX_DATE		varchar (19)  		 NULL,
			ACCT_LVL		varchar (2)  		 NULL,
			CHK_STAT		varchar (2)  		 NULL,
			STAT		varchar (2)  		 NULL,
			RET_CODE		varchar (10)  		 NULL,
			RET_MSG		varchar (128)  		 NULL,
			HOST_MSG		varchar (128)  		 NULL,
			RET_TIME		varchar (19)  		 NULL,
			TIME_SEC		int (10)  		 NULL,
			OPEN_BRCH		varchar (12)  		 NULL,
			HOST_DATE		varchar (19)  		 NULL,
			HOST_SEQ		varchar (20)  		 NULL,
			REFUND_AMT		double (16,2)  		 NULL,
			CHK_FLAG		varchar (20)  		 NULL,
			CHK_MSG		varchar (60)  		 NULL,
			AMT1		double (16,2)  		 NULL,
			AMT2		double (16,2)  		 NULL,
			RMRK		varchar (60)  		 NULL,
			RMRK1		varchar (100)  		 NULL,
			RMRK2		varchar (200)  		 NULL
);

CREATE UNIQUE INDEX ui_T_NCP_BOOK_HIST ON T_NCP_BOOK_HIST
(
PLAT_DATE,
SEQ_NO
);
CREATE UNIQUE INDEX ui_T_NCP_BOOK_HIST1 ON T_NCP_BOOK_HIST
(
SND_BRCH,
OTH_SEQ
);

/*==============================================================*/
/* Table:T_NCP_BOOK_EXT_HIST	*/
/*==============================================================*/
CREATE TABLE T_NCP_BOOK_EXT_HIST(
			PLAT_DATE		varchar (8)  		 NULL,
			SEQ_NO		int (10)  		 NULL,
			TX_CODE		varchar (40)  		 NULL,
			MRCHNT_NO		varchar (15)  		 NULL,
			MRCHNT_TYPE		varchar (4)  		 NULL,
			MRCHNT_NAME		varchar (80)  		 NULL,
			SUBMRCHNT_NO		varchar (15)  		 NULL,
			SUBMRCHNT_TYPE		varchar (4)  		 NULL,
			SUBMRCHNT_NAME		varchar (80)  		 NULL,
			INST_BRCH		varchar (11)  		 NULL,
			INST_ACCT_NO		varchar (34)  		 NULL,
			INST_ACCT_NAME		varchar (120)  		 NULL,
			DEV_DES		varchar (400)  		 NULL,
			DEV_LANG		varchar (3)  		 NULL,
			IP		varchar (64)  		 NULL,
			MAC		varchar (64)  		 NULL,
			DEV_NO		varchar (129)  		 NULL,
			GPS		varchar (32)  		 NULL,
			SIM_NO		varchar (32)  		 NULL,
			SIM_NUM		int (10)  		 NULL,
			USER_ID		varchar (100)  		 NULL,
			RISK		varchar (8)  		 NULL,
			REASON		varchar (200)  		 NULL,
			REG_DATE		varchar (14)  		 NULL,
			EMAIL		varchar (128)  		 NULL,
			PRO_CODE		varchar (4)  		 NULL,
			CITY_CODE		varchar (4)  		 NULL,
			GOOD_TYPE		varchar (10)  		 NULL,
			CHNL_BRCH		varchar (100)  		 NULL,
			ENTR_ACCT_NAME		varchar (240)  		 NULL,
			RGST_NO		varchar (20)  		 NULL,
			SND_ACCT_NO		varchar (34)  		 NULL,
			PAY_ACCT_INFO		varchar (64)  		 NULL,
			PRODUCT_DESC		varchar (240)  		 NULL,
			ORDER_DESC		varchar (128)  		 NULL,
			AMT1		double (16,2)  		 NULL,
			AMT2		double (16,2)  		 NULL,
			RMRK		varchar (60)  		 NULL,
			RMRK1		varchar (100)  		 NULL,
			RMRK2		varchar (200)  		 NULL
);

CREATE UNIQUE INDEX ui_T_NCP_BOOK_EXT_HIST ON T_NCP_BOOK_EXT_HIST
(
PLAT_DATE,
SEQ_NO
);

/*==============================================================*/
/* Table:T_AUTO_PARA	*/
/*==============================================================*/
CREATE TABLE T_AUTO_PARA(
			DTA_NAME		varchar (50)  		 NOT NULL,
			SVC_NAME		varchar (50)  		 NULL,
			INTVL		int (10)  		 NULL,
			MAX_TIMES		int (10)  		 NULL,
			INTVL_ADD		int (10)  		 NULL,
			DEAL_NUM		int (10)  		 NULL,
			RMRK		varchar (60)  		 NULL,
			RMRK1		varchar (100)  		 NULL,
			RMRK2		varchar (200)  		 NULL,
			DAC		varchar (16)  		 NULL
);


/*==============================================================*/
/* Table:T_SMS_CONFIRM	*/
/*==============================================================*/
CREATE TABLE T_SMS_CONFIRM(
			PLAT_DATE		varchar (8)  		 NULL,
			SEQ_NO		int (10)  		 NULL,
			SIGN_BRCH		varchar (11)  		 NULL,
			OTH_SEQ		varchar (16)  		 NULL,
			VRFY_NO		int (10)  		 NULL,
			LINK_CODE		varchar (50)  		 NOT NULL,
			PHN		varchar (18)  		 NULL,
			TX_DATE		varchar (19)  		 NULL,
			INVL_DATE		varchar (19)  		 NULL,
			FAIL_TIMES		int (10)  		 NULL,
			FLAG		varchar (2)  		 NULL,
			RMRK		varchar (60)  		 NULL,
			RMRK1		varchar (100)  		 NULL,
			RMRK2		varchar (200)  		 NULL
);


/*==============================================================*/
/* Table:T_CHK_SYS	*/
/*==============================================================*/
CREATE TABLE T_CHK_SYS(
			CHK_DATE		varchar (10)  		 NOT NULL,
			ENTR_NO		varchar (11)  		 NOT NULL,
			BUSI_NO		varchar (4)  		 NULL,
			BUSI_IDX_TYPE		varchar (1)  		 NULL,
			AREA_NO		varchar (9)  		 NULL,
			LOC_STAT		varchar (1)  		 NULL,
			HOST_STAT		varchar (1)  		 NULL,
			CUP_STAT		varchar (1)  		 NULL,
			CHK_STAT		varchar (1)  		 NULL,
			CLEAR_STAT		varchar (1)  		 NULL,
			FLAG		varchar (1)  		 NULL,
			CHK_TIMES		int (10)  		 NULL,
			FILE_NAME		varchar (60)  		 NULL,
			DAC		varchar (16)  		 NULL
);


/*==============================================================*/
/* Table:T_END_STEP	*/
/*==============================================================*/
CREATE TABLE T_END_STEP(
			BAT_NO		int (10)  		 NOT NULL,
			BAT_NAME		varchar (60)  		 NULL,
			BAT_STAT		varchar (1)  		 NOT NULL,
			ERR_MSG		varchar (255)  		 NULL,
			DTA_NAME		varchar (50)  		 NULL,
			SVC_NAME		varchar (50)  		 NULL,
			BEG_DATE		varchar (8)  		 NULL,
			BEG_TIME		varchar (6)  		 NULL,
			END_DATE		varchar (8)  		 NULL,
			END_TIME		varchar (6)  		 NULL,
			BAT_FLAG		varchar (1)  		 NOT NULL,
			DAC		varchar (16)  		 NULL
);

CREATE UNIQUE INDEX ui_t_end_step ON T_END_STEP
(
BAT_NO
);

/*==============================================================*/
/* Table:T_NCP_SIGN	*/
/*==============================================================*/
CREATE TABLE T_NCP_SIGN(
			ACCT_NO		varchar (40)  		 NULL,
			SIGN_BRCH		varchar (11)  		 NULL,
			PAY_ACCT_INFO		varchar (64)  		 NULL,
			PHN		varchar (18)  		 NULL,
			SIGN_TYPE		varchar (2)  		 NULL,
			SIGN_NO		varchar (55)  		 NULL,
			ACCT_NAME		varchar (160)  		 NULL,
			OPEN_BRCH		varchar (12)  		 NULL,
			STAT		varchar (1)  		 NULL,
			SIGN_DATE		varchar (19)  		 NULL,
			UNSIGN_DATE		varchar (19)  		 NULL,
			CERT_TYPE		varchar (2)  		 NULL,
			CERT_NO		varchar (20)  		 NULL,
			ACCT_NO2		varchar (40)  		 NULL,
			SIGN_CHNL		varchar (3)  		 NULL,
			BRCH_NO		varchar (11)  		 NULL,
			SIGN_TELLER		varchar (10)  		 NULL,
			UNSIGN_BRCH		varchar (11)  		 NULL,
			UNSIGN_TELLER		varchar (10)  		 NULL,
			LINK_CODE		varchar (50)  		 NULL,
			RMRK		varchar (60)  		 NULL,
			RMRK1		varchar (100)  		 NULL,
			RMRK2		varchar (200)  		 NULL
);


/*==============================================================*/
/* Table:T_NCP_SIGN_HIST	*/
/*==============================================================*/
CREATE TABLE T_NCP_SIGN_HIST(
			ACCT_NO		varchar (40)  		 NULL,
			SIGN_BRCH		varchar (11)  		 NULL,
			PAY_ACCT_INFO		varchar (64)  		 NULL,
			PHN		varchar (18)  		 NULL,
			SIGN_TYPE		varchar (2)  		 NULL,
			SIGN_NO		varchar (55)  		 NULL,
			ACCT_NAME		varchar (160)  		 NULL,
			MIN_AMT		double (15,2)  		 NULL,
			MAX_AMT		char (15,2)  		 NOT NULL,
			STAT		varchar (1)  		 NULL,
			SIGN_DATE		varchar (19)  		 NULL,
			UNSIGN_DATE		varchar (19)  		 NULL,
			CERT_TYPE		varchar (2)  		 NULL,
			CERT_NO		varchar (20)  		 NULL,
			ACCT_NO2		varchar (40)  		 NULL,
			SIGN_CHNL		varchar (3)  		 NULL,
			BRCH_NO		varchar (11)  		 NULL,
			SIGN_TELLER		varchar (10)  		 NULL,
			UNSIGN_CHNL		varchar (3)  		 NULL,
			UNSIGN_BRCH		varchar (11)  		 NULL,
			UNSIGN_TELLER		varchar (10)  		 NULL,
			RMRK		varchar (60)  		 NULL,
			RMRK1		varchar (100)  		 NULL,
			RMRK2		varchar (200)  		 NULL
);


/*==============================================================*/
/* Table:T_BUSI_LMT	*/
/*==============================================================*/
CREATE TABLE T_BUSI_LMT(
			BUSI_TYPE		varchar (12)  		 NOT NULL,
			BUSI_TYPE_NAME		varchar (80)  		 NULL,
			CARD_TYPE		varchar (3)  		 NOT NULL,
			LMT_AMT		double (20,2)  		 NULL,
			LMT_AMT_DAY		double (20,2)  		 NULL,
			LMT_NUM_DAY		int (10)  		 NULL,
			LMT_AMT1		double (20,2)  		 NULL,
			LMT_NUM1		int (10)  		 NULL,
			LMT_AMT2		double (20,2)  		 NULL,
			LMT_NUM2		int (10)  		 NULL,
			STAT		varchar (2)  		 NULL,
			RMRK		varchar (60)  		 NULL,
			RMRK1		varchar (100)  		 NULL,
			DAC		varchar (16)  		 NULL
);


/*==============================================================*/
/* Table:T_BUSI_LMT_TOT	*/
/*==============================================================*/
CREATE TABLE T_BUSI_LMT_TOT(
			BUSI_TYPE		varchar (12)  		 NOT NULL,
			ACCT_NO		varchar (35)  		 NOT NULL,
			AMT_DAY		double (20,2)  		 NULL,
			NUM_DAY		int (10)  		 NULL,
			AMT1		double (20,2)  		 NULL,
			NUM1		int  		 NULL,
			AMT2		double (20,2)  		 NULL,
			NUM2		int  		 NULL,
			RMRK		varchar (60)  		 NULL,
			RMRK1		varchar (100)  		 NULL,
			DAC		varchar (16)  		 NULL
);


/*==============================================================*/
/* Table:T_NCP_FUND_SETT	*/
/*==============================================================*/
CREATE TABLE T_NCP_FUND_SETT(
			SETT_DATE		varchar (10)  		 NULL,
			TX_CODE		varchar (40)  		 NULL,
			HOST_CODE		varchar (10)  		 NULL,
			OPEN_BRCH		varchar (12)  		 NULL,
			PAY_ACCT_NO		varchar (34)  		 NULL,
			PAYEE_ACCT_NO		varchar (34)  		 NULL,
			TX_TYPE_CUP		varchar (6)  		 NULL,
			SND_BRCH_NO		varchar (12)  		 NULL,
			OTH_SEQ		varchar (16)  		 NULL,
			BUSI_TYPE		varchar (8)  		 NULL,
			CLEAR_DATE		varchar (10)  		 NULL,
			ORI_OTH_SEQ		varchar (16)  		 NULL,
			ORI_TX_AMT		decimal (16,2)  		 NULL,
			MRCHNT_NO		varchar (15)  		 NULL,
			MRCHNT_TYPE		varchar (4)  		 NULL,
			OUT_AMT		decimal (16,2)  		 NULL,
			IN_AMT		decimal (16,2)  		 NULL,
			CUST_FEE		decimal (16,2)  		 NULL,
			CHARGE_FEE		decimal (16,2)  		 NULL,
			LOGO_FEE		decimal (16,2)  		 NULL,
			OUT_FEE		decimal (16,2)  		 NULL,
			IN_FEE		decimal (16,2)  		 NULL,
			TX_TYPE		varchar (1)  		 NULL,
			TRAN_TYPE		varchar (1)  		 NULL,
			SETT_TYPE		varchar (1)  		 NULL,
			AMT_TYPE		varchar (1)  		 NULL,
			SETT_FLAG		varchar (1)  		 NULL,
			FILE_TYPE		varchar (20)  		 NULL,
			AMT1		decimal (16,2)  		 NULL,
			AMT2		decimal (16,2)  		 NULL,
			RMRK		varchar (60)  		 NULL,
			RMRK1		varchar (100)  		 NULL,
			RMRK2		varchar (200)  		 NULL
);


/*==============================================================*/
/* Table:T_NCP_RES_DET	*/
/*==============================================================*/
CREATE TABLE T_NCP_RES_DET(
			CLEAR_DATE		varchar (10)  		 NULL,
			FILE_TYPE		varchar (10)  		 NULL,
			OTH_SEQ		varchar (16)  		 NULL,
			TX_AMT		double (16,2)  		 NULL,
			BUSI_TYPE		varchar (8)  		 NULL,
			INST_BRCH		varchar (12)  		 NULL,
			INST_ACCT_NO		varchar (34)  		 NULL,
			PAY_BRCH		varchar (12)  		 NULL,
			PAY_ACCT_TYPE		varchar (2)  		 NULL,
			PAY_ACCT_NO		varchar (34)  		 NULL,
			PAYEE_BRCH		varchar (12)  		 NULL,
			PAYEE_ACCT_TYPE		varchar (2)  		 NULL,
			PAYEE_ACCT_NO		varchar (34)  		 NULL,
			AMT1		double (16,2)  		 NULL,
			AMT2		double (16,2)  		 NULL,
			RMRK		varchar (60)  		 NULL,
			RMRK1		varchar (100)  		 NULL,
			RMRK2		varchar (200)  		 NULL
);


/*==============================================================*/
/* Table:T_NCP_ERR_DETAIL	*/
/*==============================================================*/
CREATE TABLE T_NCP_ERR_DETAIL(
			SETT_DATE		varchar (10)  		 NULL,
			FILE_TYPE		varchar (10)  		 NULL,
			TX_CODE		varchar (40)  		 NULL,
			TX_TYPE_CUP		varchar (8)  		 NULL,
			OTH_SEQ		varchar (16)  		 NULL,
			TX_AMT		decimal (16,2)  		 NULL,
			BUSI_TYPE		varchar (8)  		 NULL,
			CLEAR_DATE		varchar (10)  		 NULL,
			ERR_TYPE		varchar (3)  		 NULL,
			ERR_REASON		varchar (4)  		 NULL,
			ORI_OTH_SEQ		varchar (16)  		 NULL,
			ORI_TX_AMT		decimal (16,2)  		 NULL,
			SND_BRCH_NO		varchar (12)  		 NULL,
			PAY_BRCH		varchar (12)  		 NULL,
			PAY_ACCT_TYPE		varchar (2)  		 NULL,
			PAY_ACCT_NO		varchar (34)  		 NULL,
			CHNL_BRCH		varchar (70)  		 NULL,
			SIGN_NO		varchar (55)  		 NULL,
			PAYEE_BRCH		varchar (12)  		 NULL,
			PAYEE_ACCT_TYPE		varchar (2)  		 NULL,
			PAYEE_ACCT_NO		varchar (34)  		 NULL,
			INST_BRCH		varchar (12)  		 NULL,
			INST_ACCT_NO		varchar (34)  		 NULL,
			PRODUCT_TYPE		varchar (8)  		 NULL,
			PRODUCT_DESC		varchar (120)  		 NULL,
			MRCHNT_NO		varchar (15)  		 NULL,
			MRCHNT_TYPE		varchar (4)  		 NULL,
			SUBMRCHNT_NO		varchar (15)  		 NULL,
			SUBMRCHNT_TYPE		varchar (4)  		 NULL,
			TERM_TYPE		varchar (2)  		 NULL,
			OUT_AMT		decimal (16,2)  		 NULL,
			IN_AMT		decimal (16,2)  		 NULL,
			CHARGE_FEE		decimal (16,2)  		 NULL,
			LOGO_FEE		decimal (16,2)  		 NULL,
			ERR_FEE		decimal (16,2)  		 NULL,
			OUT_FEE		decimal (16,2)  		 NULL,
			IN_FEE		decimal (16,2)  		 NULL,
			ERR_FLAG		varchar (1)  		 NULL,
			PROC_FLAG		varchar (2)  		 NULL,
			ERR_PLAT_DATE		varchar (10)  		 NULL,
			ERR_PLAT_SEQ		int (10)  		 NULL,
			ERR_HOST_DATE		varchar (10)  		 NULL,
			ERR_HOST_SEQ		varchar (19)  		 NULL,
			OPEN_BRCH		varchar (12)  		 NULL,
			ERR_BRCH_NO		varchar (12)  		 NULL,
			TELLER_NO		varchar (10)  		 NULL,
			RCK_TELLER		varchar (10)  		 NULL,
			ERR_MSG		varchar (120)  		 NULL,
			AMT1		decimal (16,2)  		 NULL,
			AMT2		decimal (16,2)  		 NULL,
			RMRK		varchar (60)  		 NULL,
			RMRK1		varchar (100)  		 NULL,
			RMRK2		varchar (200)  		 NULL
);


/*==============================================================*/
/* Table:T_NCP_SETT_DET	*/
/*==============================================================*/
CREATE TABLE T_NCP_SETT_DET(
			CLEAR_DATE		varchar (10)  		 NULL,
			TX_TYPE		varchar (8)  		 NULL,
			PAY_NUM		int (10)  		 NULL,
			IN_FEE		double (16,2)  		 NULL,
			PAY_AMT		double (16,2)  		 NULL,
			AC_PAY_AMT		double (16,2)  		 NULL,
			AC_IN_FEE		double (16,2)  		 NULL,
			IS_IN_FEE		double (16,2)  		 NULL,
			IS_PAY_AMT		double (16,2)  		 NULL,
			PAYEE_NUM		int (10)  		 NULL,
			PAYEE_AMT		double (16,2)  		 NULL,
			AC_PAYEE_AMT		double (16,2)  		 NULL,
			IS_PAYEE_AMT		double (16,2)  		 NULL,
			CHARGE_FEE		double (16,2)  		 NULL,
			BRAND_FEE		double (16,2)  		 NULL,
			AC_OUT_FEE		double (16,2)  		 NULL,
			IS_OUT_FEE		double (16,2)  		 NULL,
			OUT_FEE		char (16,2)  		 NULL,
			ERR_FEE		double (16,2)  		 NULL,
			AMT1		double (16,2)  		 NULL,
			AMT2		double (16,2)  		 NULL,
			RMRK		varchar (60)  		 NULL,
			RMRK1		varchar (100)  		 NULL,
			RMRK2		varchar (200)  		 NULL
);


/*==============================================================*/
/* Table:T_NCP_SETT_TOT	*/
/*==============================================================*/
CREATE TABLE T_NCP_SETT_TOT(
			CLEAR_DATE		varchar (10)  		 NULL,
			PAY_NUM		int (10)  		 NULL,
			OUT_FEE		double (16,2)  		 NULL,
			AC_OUT_FEE		double (16,2)  		 NULL,
			IS_OUT_FEE		double (16,2)  		 NULL,
			PAYEE_NUM		int (10)  		 NULL,
			IN_FEE		double (16,2)  		 NULL,
			AC_IN_FEE		double (16,2)  		 NULL,
			IS_IN_FEE		double (16,2)  		 NULL,
			CHARGE_FEE		double (16,2)  		 NULL,
			BRAND_FEE		double (16,2)  		 NULL,
			ERR_FEE		double (16,2)  		 NULL,
			AMT1		double (16,2)  		 NULL,
			AMT2		double (16,2)  		 NULL,
			RMRK		varchar (60)  		 NULL,
			RMRK1		varchar (100)  		 NULL,
			RMRK2		varchar (200)  		 NULL
);


/*==============================================================*/
/* Table:T_CHK_ERR	*/
/*==============================================================*/
CREATE TABLE T_CHK_ERR(
			CLEAR_DATE		varchar (12)  		 NULL,
			ENTR_NO		varchar (10)  		 NULL,
			BUSI_NO		varchar (4)  		 NULL,
			BUSI_IDX_TYPE		varchar (1)  		 NULL,
			PLAT_DATE		varchar (8)  		 NULL,
			SEQ_NO		int (10)  		 NULL,
			BRCH_NO		varchar (11)  		 NULL,
			AREA_NO		varchar (9)  		 NULL,
			TX_CODE		varchar (40)  		 NULL,
			TX_TYPE_CUP		varchar (8)  		 NULL,
			HOST_DATE		varchar (10)  		 NULL,
			HOST_SEQ		varchar (19)  		 NULL,
			OTH_DATE		varchar (19)  		 NULL,
			OTH_SEQ		varchar (20)  		 NULL,
			BUSI_IDX		varchar (30)  		 NULL,
			ACCT_BRCH		varchar (12)  		 NULL,
			ACCT_NO1		varchar (35)  		 NULL,
			ACCT_NO2		varchar (35)  		 NULL,
			TX_DATE		varchar (19)  		 NULL,
			TX_TIME		varchar (6)  		 NULL,
			TX_AMT		decimal (16,2)  		 NULL,
			FEE		decimal (16,2)  		 NULL,
			CURR_NO		varchar (3)  		 NULL,
			HOST_CHK_FLAG		varchar (1)  		 NULL,
			OTH_CHK_FLAG		varchar (1)  		 NULL,
			PROC_FLAG		varchar (1)  		 NULL,
			ERR_FLAG		varchar (1)  		 NULL,
			HOST_MSG		varchar (60)  		 NULL,
			OTH_MSG		varchar (60)  		 NULL,
			CHK_MSG		varchar (60)  		 NULL,
			ERR_PLAT_DATE		varchar (10)  		 NULL,
			ERR_PLAT_SEQ		int (10)  		 NULL,
			ERR_HOST_DATE		varchar (10)  		 NULL,
			ERR_HOST_SEQ		varchar (19)  		 NULL,
			OPEN_BRCH		varchar (12)  		 NULL,
			ERR_BRCH_NO		varchar (12)  		 NULL,
			TELLER_NO		varchar (10)  		 NULL,
			RCK_TELLER		varchar (10)  		 NULL,
			ERR_MSG		varchar (120)  		 NULL,
			CHARGE_FEE		decimal (16,2)  		 NULL,
			LOGO_FEE		decimal (16,2)  		 NULL,
			OUT_FEE		decimal (16,2)  		 NULL,
			IN_FEE		decimal (16,2)  		 NULL,
			AMT1		decimal (16,2)  		 NULL,
			AMT2		decimal (16,2)  		 NULL,
			AMT3		decimal (16,2)  		 NULL,
			NUM1		int (10)  		 NULL,
			NUM2		int (10)  		 NULL,
			NUM3		int (10)  		 NULL,
			STR1		varchar (20)  		 NULL,
			STR2		varchar (60)  		 NULL,
			STR3		varchar (100)  		 NULL,
			DAC		varchar (16)  		 NULL
);

